package quizapp.ui.admin;

public class EditSubject {

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
