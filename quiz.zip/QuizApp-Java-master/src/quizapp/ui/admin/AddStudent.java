package quizapp.ui.admin;

import javax.swing.*;
import java.awt.*;
import repositories.AdminRepository;
import services.AdminService;

public class AddStudent extends javax.swing.JFrame {

    private final AdminService adminService;
    private BackgroundPanel jPanel1; // Custom JPanel with background support

    public AddStudent() {
        this.adminService = new AdminRepository();
        initComponents();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        // Create a custom panel with the background image
        jPanel1 = new BackgroundPanel("/quizapp/ui/admin/addStudent-page.jpg");
        jPanel1.setLayout(null); // Absolute positioning

        // Add components
        JLabel jLabel1 = new JLabel("Add Student");
        jLabel1.setFont(new Font("SansSerif", Font.BOLD, 24));
        jLabel1.setForeground(Color.BLACK); // Make text visible on image
        jLabel1.setBounds(600, 100, 200, 40);
        jPanel1.add(jLabel1);

        JLabel jLabel2 = new JLabel("Username:");
        jLabel2.setFont(new Font("SansSerif", Font.BOLD, 16));
        jLabel2.setForeground(Color.BLACK);
        jLabel2.setBounds(500, 200, 100, 30);
        jPanel1.add(jLabel2);

        JLabel jLabel3 = new JLabel("Password:");
        jLabel3.setFont(new Font("SansSerif", Font.BOLD, 16));
        jLabel3.setForeground(Color.BLACK);
        jLabel3.setBounds(500, 260, 100, 30);
        jPanel1.add(jLabel3);

        JTextField username = new JTextField();
        username.setFont(new Font("SansSerif", Font.PLAIN, 16));
        username.setBounds(620, 200, 250, 30);
        jPanel1.add(username);

        JPasswordField password = new JPasswordField();
        password.setFont(new Font("SansSerif", Font.PLAIN, 16));
        password.setBounds(620, 260, 250, 30);
        jPanel1.add(password);

        JButton back = new JButton("Back");
        back.setFont(new Font("SansSerif", Font.BOLD, 16));
        back.setBounds(500, 350, 120, 40);
        back.addActionListener(evt -> backActionPerformed(evt));
        jPanel1.add(back);

        JButton submit = new JButton("Submit");
        submit.setFont(new Font("SansSerif", Font.BOLD, 16));
        submit.setBounds(750, 350, 120, 40);
        submit.addActionListener(evt -> submitActionPerformed(username, password));
        jPanel1.add(submit);

        // Set frame properties
        setContentPane(jPanel1);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximize window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Add Student");
        setResizable(false);
        setVisible(true);
    }

    private void backActionPerformed(java.awt.event.ActionEvent evt) {
        this.dispose();
        new AdminDashboard().setVisible(true);
    }

    private void submitActionPerformed(JTextField username, JPasswordField password) {
        String studentUsername = username.getText().trim();
        String studentPassword = new String(password.getPassword()).trim();

        if (studentUsername.isEmpty() || studentPassword.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Username and Password cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean isCreated = adminService.createStudent(studentUsername, studentPassword);
        if (isCreated) {
            JOptionPane.showMessageDialog(null, "Student added successfully!");
            username.setText("");
            password.setText("");
        } else {
            JOptionPane.showMessageDialog(null, "Failed to add student. Username already exists.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new AddStudent().setVisible(true));
    }

    // Custom JPanel class for setting a background image
    class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            try {
                backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
            } catch (Exception e) {
                System.out.println("Error loading background image: " + e.getMessage());
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
