package quizapp.ui.admin;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class AddQuestion extends javax.swing.JFrame {
    private Connection conn;

    private JComboBox<String> subjectComboBox, levelComboBox, setComboBox, answer;
    private JTextArea question, optionA, optionB, optionC, optionD;
    private JButton back, submit;
    private BackgroundPanel jPanel1;

    public AddQuestion() {
        initComponents();
        connectDatabase();
        fetchSubjects();
        fetchLevels();
        fetchSets();
    }

    private void connectDatabase() {
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/data", "postgres", "root");
            System.out.println("Database Connected Successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void fetchSubjects() {
        populateComboBox(subjectComboBox, "SELECT name FROM subjects");
    }

    private void fetchLevels() {
        populateComboBox(levelComboBox, "SELECT name FROM levels");
    }

    private void fetchSets() {
        populateComboBox(setComboBox, "SELECT name FROM sets");
    }

    private void populateComboBox(JComboBox<String> comboBox, String query) {
        comboBox.removeAllItems();
        try (PreparedStatement pst = conn.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                comboBox.addItem(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to fetch data!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jPanel1 = new BackgroundPanel();
        jPanel1.setLayout(null);

        JLabel titleLabel = new JLabel("Add Question");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        titleLabel.setBounds(200, 10, 200, 30);
        jPanel1.add(titleLabel);

        subjectComboBox = new JComboBox<>();
        levelComboBox = new JComboBox<>();
        setComboBox = new JComboBox<>();
        question = new JTextArea();
        optionA = new JTextArea();
        optionB = new JTextArea();
        optionC = new JTextArea();
        optionD = new JTextArea();
        answer = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        back = new JButton("Back");
        submit = new JButton("Submit");

        JLabel subjectLabel = new JLabel("Subject:");
        JLabel levelLabel = new JLabel("Level:");
        JLabel setLabel = new JLabel("Set:");
        JLabel questionLabel = new JLabel("Question:");
        JLabel optionALabel = new JLabel("Option A:");
        JLabel optionBLabel = new JLabel("Option B:");
        JLabel optionCLabel = new JLabel("Option C:");
        JLabel optionDLabel = new JLabel("Option D:");
        JLabel answerLabel = new JLabel("Correct Answer:");

        // Set bounds for labels
        subjectLabel.setBounds(50, 50, 100, 25);
        levelLabel.setBounds(50, 90, 100, 25);
        setLabel.setBounds(50, 130, 100, 25);
        questionLabel.setBounds(50, 170, 100, 25);
        optionALabel.setBounds(50, 250, 100, 25);
        optionBLabel.setBounds(50, 310, 100, 25);
        optionCLabel.setBounds(50, 370, 100, 25);
        optionDLabel.setBounds(50, 430, 100, 25);
        answerLabel.setBounds(50, 490, 120, 25);

        // Set bounds for input fields
        subjectComboBox.setBounds(180, 50, 200, 25);
        levelComboBox.setBounds(180, 90, 200, 25);
        setComboBox.setBounds(180, 130, 200, 25);
        question.setBounds(180, 170, 300, 70);
        optionA.setBounds(180, 250, 300, 40);
        optionB.setBounds(180, 310, 300, 40);
        optionC.setBounds(180, 370, 300, 40);
        optionD.setBounds(180, 430, 300, 40);
        answer.setBounds(180, 490, 100, 25);

        back.setBounds(100, 550, 100, 40);
        submit.setBounds(250, 550, 100, 40);

        // Set label text color to white
        Color labelColor = Color.WHITE;
        titleLabel.setForeground(labelColor);
        subjectLabel.setForeground(labelColor);
        levelLabel.setForeground(labelColor);
        setLabel.setForeground(labelColor);
        questionLabel.setForeground(labelColor);
        optionALabel.setForeground(labelColor);
        optionBLabel.setForeground(labelColor);
        optionCLabel.setForeground(labelColor);
        optionDLabel.setForeground(labelColor);
        answerLabel.setForeground(labelColor);

        // Add components to panel
        jPanel1.add(subjectLabel);
        jPanel1.add(levelLabel);
        jPanel1.add(setLabel);
        jPanel1.add(questionLabel);
        jPanel1.add(optionALabel);
        jPanel1.add(optionBLabel);
        jPanel1.add(optionCLabel);
        jPanel1.add(optionDLabel);
        jPanel1.add(answerLabel);

        jPanel1.add(subjectComboBox);
        jPanel1.add(levelComboBox);
        jPanel1.add(setComboBox);
        jPanel1.add(question);
        jPanel1.add(optionA);
        jPanel1.add(optionB);
        jPanel1.add(optionC);
        jPanel1.add(optionD);
        jPanel1.add(answer);
        jPanel1.add(back);
        jPanel1.add(submit);

        // Add action listeners
        submit.addActionListener(evt -> submitActionPerformed());
        back.addActionListener(evt -> backActionPerformed());

        // Clear fields when combo boxes change
        subjectComboBox.addActionListener(e -> clearFields());
        levelComboBox.addActionListener(e -> clearFields());
        setComboBox.addActionListener(e -> clearFields());

        setContentPane(jPanel1); // Set custom background panel
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 650);
        setLocationRelativeTo(null);
    }

    private void submitActionPerformed() {
        if (conn == null) {
            JOptionPane.showMessageDialog(null, "Database Connection is not established!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String sql = "INSERT INTO questions (subject_id, level_id, set_id, question_text, option_a, option_b, option_c, option_d, correct_option) " +
                    "VALUES ((SELECT id FROM subjects WHERE name = ?), " +
                    "(SELECT id FROM levels WHERE name = ?), " +
                    "(SELECT id FROM sets WHERE name = ?), ?, ?, ?, ?, ?, ?)";

            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, subjectComboBox.getSelectedItem().toString());
            pst.setString(2, levelComboBox.getSelectedItem().toString());
            pst.setString(3, setComboBox.getSelectedItem().toString());
            pst.setString(4, question.getText().trim());
            pst.setString(5, optionA.getText().trim());
            pst.setString(6, optionB.getText().trim());
            pst.setString(7, optionC.getText().trim());
            pst.setString(8, optionD.getText().trim());
            pst.setString(9, answer.getSelectedItem().toString());

            int added = pst.executeUpdate();
            JOptionPane.showMessageDialog(null, added > 0 ? "Question added successfully!" : "Failed to add question!", "Result", JOptionPane.INFORMATION_MESSAGE);

            if (added > 0) {
                clearFields();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "SQL Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void backActionPerformed() {
        this.dispose();
        new AdminDashboard().setVisible(true);
    }

    private void clearFields() {
        question.setText("");
        optionA.setText("");
        optionB.setText("");
        optionC.setText("");
        optionD.setText("");
        answer.setSelectedIndex(0);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new AddQuestion().setVisible(true));
    }
}

// ✅ BackgroundPanel with image
class BackgroundPanel extends JPanel {
    private Image backgroundImage;

    public BackgroundPanel() {
        try {
            backgroundImage = new ImageIcon(getClass().getResource("/quizapp/ui/admin/add-question.jpg")).getImage();
        } catch (Exception e) {
            System.err.println("Background image not found or path is incorrect!");
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
