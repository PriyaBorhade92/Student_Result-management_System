package quizapp.ui.admin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class ViewQuestion extends JFrame {
    private Connection conn;
    private JComboBox<String> subjectDropdown, levelDropdown, setDropdown;
    private JTable questionTable;
    private DefaultTableModel tableModel;
    private JButton loadButton, backButton;

    public ViewQuestion() {
        connectDatabase();
        initComponents();
        loadSubjects();
        loadLevels();
        loadSets();
    }

    private void connectDatabase() {
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/data", "postgres", "root");
            System.out.println("Database Connected Successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void initComponents() {
        setTitle("View Questions");
        setSize(1000, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Custom background panel
        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(new BorderLayout());
        backgroundPanel.setOpaque(false);
        setContentPane(backgroundPanel);

        // Filter Panel
        JPanel filterPanel = new JPanel();
        filterPanel.setOpaque(false);

        JLabel subjectLabel = new JLabel("Subject:");
        subjectLabel.setForeground(Color.WHITE);
        filterPanel.add(subjectLabel);
        subjectDropdown = new JComboBox<>();
        filterPanel.add(subjectDropdown);

        JLabel levelLabel = new JLabel("Level:");
        levelLabel.setForeground(Color.CYAN);
        filterPanel.add(levelLabel);
        levelDropdown = new JComboBox<>();
        filterPanel.add(levelDropdown);

        JLabel setLabel = new JLabel("Set:");
        setLabel.setForeground(Color.CYAN);
        filterPanel.add(setLabel);
        setDropdown = new JComboBox<>();
        filterPanel.add(setDropdown);

        loadButton = new JButton("Load Questions");
        loadButton.addActionListener(e -> loadQuestions());
        filterPanel.add(loadButton);

        backgroundPanel.add(filterPanel, BorderLayout.NORTH);

        // Table setup
        tableModel = new DefaultTableModel(new Object[]{"ID", "Question", "Option A", "Option B", "Option C", "Option D", "Correct", "Edit", "Delete"}, 0);
        questionTable = new JTable(tableModel);
        questionTable.setFont(new Font("Arial", Font.PLAIN, 14));
        questionTable.setRowHeight(30);
        questionTable.setForeground(Color.WHITE);
        questionTable.setBackground(new Color(0, 0, 0, 0));
        questionTable.setOpaque(false);
        questionTable.setGridColor(Color.WHITE);
        questionTable.setShowGrid(true);

        questionTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        questionTable.getTableHeader().setOpaque(false);
        questionTable.getTableHeader().setBackground(new Color(0, 0, 0, 0));
        questionTable.getTableHeader().setForeground(Color.BLACK);

        questionTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = questionTable.getSelectedRow();
                int col = questionTable.getSelectedColumn();
                if (col == 7) editQuestion((int) tableModel.getValueAt(row, 0));
                else if (col == 8) deleteQuestion((int) tableModel.getValueAt(row, 0));
            }
        });

        JScrollPane scrollPane = new JScrollPane(questionTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        backgroundPanel.add(scrollPane, BorderLayout.CENTER);

        // Back Button
        backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            dispose();
            new AdminDashboard().setVisible(true);
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.add(backButton);
        backgroundPanel.add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void loadSubjects() {
        subjectDropdown.removeAllItems();
        try (PreparedStatement pst = conn.prepareStatement("SELECT name FROM subjects");
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                subjectDropdown.addItem(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadLevels() {
        levelDropdown.removeAllItems();
        try (PreparedStatement pst = conn.prepareStatement("SELECT name FROM levels");
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                levelDropdown.addItem(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadSets() {
        setDropdown.removeAllItems();
        try (PreparedStatement pst = conn.prepareStatement("SELECT name FROM sets");
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                setDropdown.addItem(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadQuestions() {
        tableModel.setRowCount(0);
        String subject = (String) subjectDropdown.getSelectedItem();
        String level = (String) levelDropdown.getSelectedItem();
        String set = (String) setDropdown.getSelectedItem();

        String query = "SELECT * FROM questions WHERE subject_id IN (SELECT id FROM subjects WHERE name=?) " +
                "AND level_id IN (SELECT id FROM levels WHERE name=?) " +
                "AND set_id IN (SELECT id FROM sets WHERE name=?)";
        try (PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, subject);
            pst.setString(2, level);
            pst.setString(3, set);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("question_text"),
                        rs.getString("option_a"),
                        rs.getString("option_b"),
                        rs.getString("option_c"),
                        rs.getString("option_d"),
                        rs.getString("correct_option"),
                        "Edit", "Delete"
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load questions!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editQuestion(int questionId) {
        JPanel panel = new JPanel(new GridLayout(6, 2));

        JTextField questionField = new JTextField();
        JTextField optionAField = new JTextField();
        JTextField optionBField = new JTextField();
        JTextField optionCField = new JTextField();
        JTextField optionDField = new JTextField();
        JTextField correctOptionField = new JTextField();

        panel.add(new JLabel("Question:"));
        panel.add(questionField);
        panel.add(new JLabel("Option A:"));
        panel.add(optionAField);
        panel.add(new JLabel("Option B:"));
        panel.add(optionBField);
        panel.add(new JLabel("Option C:"));
        panel.add(optionCField);
        panel.add(new JLabel("Option D:"));
        panel.add(optionDField);
        panel.add(new JLabel("Correct Option:"));
        panel.add(correctOptionField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Edit Question", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String newQuestion = questionField.getText().trim();
            String newOptionA = optionAField.getText().trim();
            String newOptionB = optionBField.getText().trim();
            String newOptionC = optionCField.getText().trim();
            String newOptionD = optionDField.getText().trim();
            String newCorrectOption = correctOptionField.getText().trim();

            if (newQuestion.isEmpty() || newOptionA.isEmpty() || newOptionB.isEmpty() ||
                newOptionC.isEmpty() || newOptionD.isEmpty() || newCorrectOption.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String updateQuery = "UPDATE questions SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=? WHERE id=?";
            try (PreparedStatement pst = conn.prepareStatement(updateQuery)) {
                pst.setString(1, newQuestion);
                pst.setString(2, newOptionA);
                pst.setString(3, newOptionB);
                pst.setString(4, newOptionC);
                pst.setString(5, newOptionD);
                pst.setString(6, newCorrectOption);
                pst.setInt(7, questionId);
                pst.executeUpdate();
                loadQuestions();
                JOptionPane.showMessageDialog(null, "Question updated successfully!");
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to update question!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteQuestion(int questionId) {
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this question?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (PreparedStatement pst = conn.prepareStatement("DELETE FROM questions WHERE id = ?")) {
                pst.setInt(1, questionId);
                pst.executeUpdate();
                loadQuestions();
                JOptionPane.showMessageDialog(null, "Question deleted successfully!");
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to delete question!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ViewQuestion::new);
    }

    // 🔻 Background Panel Inner Class
    class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel() {
            try {
                backgroundImage = new ImageIcon(getClass().getResource("/quizapp/ui/admin/add-question.jpg")).getImage();
            } catch (Exception e) {
                System.err.println("Background image not found!");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
