package quizapp.ui.admin;

import javax.swing.*;
import java.awt.*;
import quizapp.ui.Login;

public class AdminDashboard extends JFrame {

    private JPanel jPanel1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JButton addStudent;
    private JButton addQuestion;
    private JButton viewQuestion;
    private JButton viewResult;
    private JButton backButton;
    private ImageIcon backgroundIcon;

    public AdminDashboard() {
        initComponents();
    }

    private void initComponents() {
        // Load background image
        backgroundIcon = new ImageIcon(getClass().getResource("/quizapp/ui/admin/adminDashboard-page.jpg"));

        // Panel with custom background painting
        jPanel1 = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundIcon != null) {
                    Image img = backgroundIcon.getImage();
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        jPanel1.setLayout(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setResizable(true);
        setUndecorated(false);

        // Back Button (top-left corner)
        backButton = new JButton("←");
        backButton.setFont(new Font("SansSerif", Font.BOLD, 40));
        backButton.setBackground(new Color(0, 0, 0, 0)); // Transparent background
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createEmptyBorder());
        backButton.setForeground(Color.WHITE);
        backButton.setBounds(20, 20, 60, 40);
        backButton.setToolTipText("Back to Login");
        backButton.addActionListener(e -> {
            this.dispose();
            new Login().setVisible(true);
        });
        jPanel1.add(backButton);

        // Title
        jLabel2 = new JLabel("Admin Dashboard");
        jLabel2.setFont(new Font("SansSerif", Font.BOLD, 34));
        jLabel2.setForeground(Color.WHITE);
        jPanel1.add(jLabel2);

        // Buttons
        addStudent = createButton("Add Student", evt -> {
            this.dispose();
            new AddStudent().setVisible(true);
        });

        addQuestion = createButton("Add Question", evt -> {
            this.dispose();
            new AddQuestion().setVisible(true);
        });

        viewQuestion = createButton("View Question", evt -> {
            this.dispose();
            new ViewQuestion().setVisible(true);
        });

        viewResult = createButton("View Result", evt -> {
            this.dispose();
            new ViewResult().setVisible(true);
        });

        // Add buttons to panel
        jPanel1.add(addStudent);
        jPanel1.add(addQuestion);
        jPanel1.add(viewQuestion);
        jPanel1.add(viewResult);

        getContentPane().add(jPanel1);

        // Dynamic repositioning
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                positionComponents();
            }
        });

        setVisible(true);
    }

    private JButton createButton(String text, java.awt.event.ActionListener action) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 18));
        button.setBackground(new Color(0, 102, 204));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.addActionListener(action);
        return button;
    }

    private void positionComponents() {
        int panelWidth = jPanel1.getWidth();
        int panelHeight = jPanel1.getHeight();
        int centerX = panelWidth / 2;

        jLabel2.setBounds(centerX - 150, panelHeight / 5, 300, 50);
        int buttonWidth = 200;
        int buttonHeight = 50;
        int spacing = 30;
        int startY = panelHeight / 3;

        addStudent.setBounds(centerX - buttonWidth / 2, startY, buttonWidth, buttonHeight);
        addQuestion.setBounds(centerX - buttonWidth / 2, startY + (buttonHeight + spacing), buttonWidth, buttonHeight);
        viewQuestion.setBounds(centerX - buttonWidth / 2, startY + 2 * (buttonHeight + spacing), buttonWidth, buttonHeight);
        viewResult.setBounds(centerX - buttonWidth / 2, startY + 3 * (buttonHeight + spacing), buttonWidth, buttonHeight);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminDashboard().setVisible(true));
    }
}
