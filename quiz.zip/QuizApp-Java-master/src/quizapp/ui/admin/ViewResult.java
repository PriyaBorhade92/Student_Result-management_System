package quizapp.ui.admin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class ViewResult extends JFrame {
    private Connection conn;
    private JTable studentTable, resultTable;
    private DefaultTableModel studentTableModel, resultTableModel;
    private JButton backButton;

    public ViewResult() {
        connectDatabase();
        initComponents();
        loadStudents();
    }

    private void connectDatabase() {
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/data", "postgres", "root");
            System.out.println("Database Connected Successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void initComponents() {
        setTitle("Quiz Results");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(new BorderLayout());
        backgroundPanel.setOpaque(false);
        setContentPane(backgroundPanel);

        // Student Panel
        JPanel studentPanel = new JPanel(new BorderLayout());
        studentPanel.setOpaque(false);
        studentPanel.setBorder(BorderFactory.createTitledBorder("Select Student"));

        studentTableModel = new DefaultTableModel(new Object[]{"Username"}, 0);
        studentTable = new JTable(studentTableModel);
        studentTable.setFont(new Font("Arial", Font.BOLD, 14));
        studentTable.setRowHeight(28);
        studentTable.setForeground(Color.WHITE);
        studentTable.setBackground(new Color(0, 0, 0, 0));
        studentTable.setOpaque(false);
        studentTable.setGridColor(Color.WHITE);
        studentTable.setShowGrid(true);

        studentTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        studentTable.getTableHeader().setOpaque(false);
        studentTable.getTableHeader().setBackground(new Color(0, 0, 0, 0));
        studentTable.getTableHeader().setForeground(Color.BLACK);

        JScrollPane studentScrollPane = new JScrollPane(studentTable);
        studentScrollPane.setOpaque(false);
        studentScrollPane.getViewport().setOpaque(false);
        studentScrollPane.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        studentPanel.add(studentScrollPane, BorderLayout.CENTER);

        // Result Panel
        JPanel resultPanel = new JPanel(new BorderLayout());
        resultPanel.setOpaque(false);
        resultPanel.setBorder(BorderFactory.createTitledBorder("Student Quiz Results"));

        resultTableModel = new DefaultTableModel(new Object[]{"ID", "Subject", "Level", "Set", "Marks", "Remark"}, 0);
        resultTable = new JTable(resultTableModel);
        resultTable.setFont(new Font("Arial", Font.PLAIN, 14));
        resultTable.setRowHeight(28);
        resultTable.setForeground(Color.WHITE);
        resultTable.setBackground(new Color(0, 0, 0, 0));
        resultTable.setOpaque(false);
        resultTable.setGridColor(Color.WHITE);
        resultTable.setShowGrid(true);

        resultTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        resultTable.getTableHeader().setOpaque(false);
        resultTable.getTableHeader().setBackground(new Color(0, 0, 0, 0));
        resultTable.getTableHeader().setForeground(Color.BLACK);

        JScrollPane resultScrollPane = new JScrollPane(resultTable);
        resultScrollPane.setOpaque(false);
        resultScrollPane.getViewport().setOpaque(false);
        resultScrollPane.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        resultPanel.add(resultScrollPane, BorderLayout.CENTER);

        // Back Button
        backButton = new JButton("Back");
        backButton.setFocusPainted(false);
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.addActionListener(e -> {
            dispose();
            new AdminDashboard().setVisible(true); // Replace with your actual dashboard class
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.add(backButton);

        backgroundPanel.add(studentPanel, BorderLayout.WEST);
        backgroundPanel.add(resultPanel, BorderLayout.CENTER);
        backgroundPanel.add(bottomPanel, BorderLayout.SOUTH);

        // Table click event
        studentTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = studentTable.getSelectedRow();
                if (selectedRow != -1) {
                    String username = studentTableModel.getValueAt(selectedRow, 0).toString();
                    loadStudentResults(username);
                }
            }
        });

        setVisible(true);
    }

    private void loadStudents() {
        studentTableModel.setRowCount(0);
        String query = "SELECT DISTINCT username FROM quiz_results";
        try (PreparedStatement pst = conn.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                studentTableModel.addRow(new Object[]{rs.getString("username")});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to fetch students!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadStudentResults(String username) {
        resultTableModel.setRowCount(0);
        String query = "SELECT id, subject, level, set, marks, total_marks FROM quiz_results WHERE username = ?";
        try (PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String subject = rs.getString("subject");
                String level = rs.getString("level");
                String set = rs.getString("set");
                int marks = rs.getInt("marks");
                int totalMarks = rs.getInt("total_marks");
                String remark = calculateRemark(marks, totalMarks);
                resultTableModel.addRow(new Object[]{id, subject, level, set, marks, remark});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to fetch student results!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String calculateRemark(int marks, int totalMarks) {
        double percentage = (double) marks / totalMarks * 100;
        if (percentage >= 90) return "Excellent";
        else if (percentage >= 75) return "Very Good";
        else if (percentage >= 50) return "Pass";
        else return "Fail";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ViewResult::new);
    }

    // 🔻 Background Panel Inner Class
    class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel() {
            try {
                backgroundImage = new ImageIcon(getClass().getResource("/quizapp/ui/admin/add-question.jpg")).getImage();
            } catch (Exception e) {
                System.err.println("Background image not found! Check the path.");
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
