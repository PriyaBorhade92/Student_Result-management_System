package quizapp.ui.student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ShowScore extends JFrame {
    private Connection conn;
    private JTable scoreTable;
    private DefaultTableModel tableModel;
    private JButton backButton;
    private ImageIcon backgroundIcon;

    public ShowScore(String username) {
        backgroundIcon = new ImageIcon(getClass().getResource("/quizapp/ui/student/studentDashboard-page.jpg")); // set your background image path
        connectDatabase();
        initComponents(username);
        loadStudentResults(username);
    }

    private void connectDatabase() {
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/data", "postgres", "root");
            System.out.println("Database Connected Successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void initComponents(String username) {
        setTitle("Your Quiz Results");
        setSize(800, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundIcon != null) {
                    g.drawImage(backgroundIcon.getImage(), 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        backgroundPanel.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Quiz Results " + username, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        backgroundPanel.add(titleLabel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"ID", "Subject", "Level", "Set", "Marks", "Total Marks", "Remark"}, 0);
        scoreTable = new JTable(tableModel);
        scoreTable.setFont(new Font("Arial", Font.BOLD, 14));
        scoreTable.setRowHeight(28);
        scoreTable.setForeground(Color.WHITE);
        scoreTable.setBackground(new Color(0, 0, 0, 0)); // Transparent background
        scoreTable.setOpaque(false);
        scoreTable.setGridColor(Color.WHITE);
        scoreTable.setShowGrid(true);

        scoreTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        scoreTable.getTableHeader().setOpaque(false);
        scoreTable.getTableHeader().setBackground(new Color(0, 0, 0, 0));
        scoreTable.getTableHeader().setForeground(Color.BLACK);

        JScrollPane scrollPane = new JScrollPane(scoreTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setOpaque(false);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        backgroundPanel.add(tablePanel, BorderLayout.CENTER);

        backButton = new JButton("Back");
        backButton.setFocusPainted(false);
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.addActionListener(e -> {
            dispose();
            new StudentDashboard(username).setVisible(true);
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.add(backButton);
        backgroundPanel.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(backgroundPanel);
        setVisible(true);
    }

    private void loadStudentResults(String username) {
        tableModel.setRowCount(0);

        String query = "SELECT id, subject, level, set, marks, total_marks FROM quiz_results WHERE username = ?";
        try (PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String subject = rs.getString("subject");
                String level = rs.getString("level");
                String set = rs.getString("set");
                int marks = rs.getInt("marks");
                int totalMarks = rs.getInt("total_marks");

                String remark = calculateRemark(marks, totalMarks);
                tableModel.addRow(new Object[]{id, subject, level, set, marks, totalMarks, remark});
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to fetch quiz results!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String calculateRemark(int marks, int totalMarks) {
        double percentage = (double) marks / totalMarks * 100;
        if (percentage >= 90) return "Excellent";
        else if (percentage >= 75) return "Very Good";
        else if (percentage >= 50) return "Pass";
        else return "Fail";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ShowScore("User")); // Replace with actual username
    }
}
