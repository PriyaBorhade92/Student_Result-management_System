package quizapp.ui.student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StudentDashboard extends javax.swing.JFrame {
    private final String username;
    private Connection conn;
    private ImageIcon backgroundIcon;

    private JPanel jPanel1;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JButton quizButton;
    private JButton scoreButton;
    private JButton backButton;

    public StudentDashboard(String username) {
        this.username = username;
        initComponents();
        connectToDatabase();

        // Make the frame fullscreen and borderless
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
    }

    private void connectToDatabase() {
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/data", "postgres", "root");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database Connection Failed: " + e.getMessage());
        }
    }

    private void initComponents() {
        backgroundIcon = new ImageIcon(getClass().getResource("/quizapp/ui/student/studentDashboard-page.jpg"));

        jPanel1 = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundIcon != null) {
                    Image img = backgroundIcon.getImage();
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        jPanel1.setLayout(null);

        // Back Button
        backButton = new JButton("←");
        backButton.setFont(new Font("SansSerif", Font.BOLD, 20));
        backButton.setBackground(new Color(255, 255, 255, 180));
        backButton.setFocusPainted(false);
        backButton.setBounds(20, 20, 60, 40);
        backButton.addActionListener(this::backButtonActionPerformed);

        // Title Label
        jLabel1 = new JLabel("Student Dashboard");
        jLabel1.setFont(new Font("sansserif", Font.BOLD, 38));
        jLabel1.setForeground(Color.WHITE);

        // Sub Label
        jLabel2 = new JLabel("Select your option");
        jLabel2.setFont(new Font("sansserif", Font.BOLD, 18));
        jLabel2.setForeground(Color.WHITE);

        // Quiz Button
        quizButton = new JButton("Quiz");
        quizButton.setBackground(new Color(0, 153, 0));
        quizButton.setForeground(Color.WHITE);
        quizButton.setFont(new Font("sansserif", Font.BOLD, 16));
        quizButton.setFocusPainted(false);
        quizButton.addActionListener(this::quizButtonActionPerformed);

        // Show Score Button
        scoreButton = new JButton("Show Score");
        scoreButton.setBackground(new Color(0, 102, 204));
        scoreButton.setForeground(Color.WHITE);
        scoreButton.setFont(new Font("sansserif", Font.BOLD, 16));
        scoreButton.setFocusPainted(false);
        scoreButton.addActionListener(this::scoreButtonActionPerformed);

        // Add components to panel
        jPanel1.add(backButton);
        jPanel1.add(jLabel1);
        jPanel1.add(jLabel2);
        jPanel1.add(quizButton);
        jPanel1.add(scoreButton);

        getContentPane().add(jPanel1);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Re-center components on resize
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                positionComponents();
            }
        });

        setVisible(true);
    }

    private void positionComponents() {
        int panelWidth = jPanel1.getWidth();
        int panelHeight = jPanel1.getHeight();

        int contentWidth = 400;
        int contentHeight = 400;

        int centerX = (panelWidth - contentWidth) / 2;
        int centerY = (panelHeight - contentHeight) / 2;

        jLabel1.setBounds(centerX, centerY, 400, 40);
        jLabel2.setBounds(centerX + 20, centerY + 100, 300, 30);
        quizButton.setBounds(centerX, centerY + 180, 150, 50);
        scoreButton.setBounds(centerX + 200, centerY + 180, 150, 50);

        backButton.setBounds(20, 20, 60, 40);
    }

    private void quizButtonActionPerformed(ActionEvent evt) {
        logAction("Started Quiz");
        this.dispose();
        new SelectSubject(username).setVisible(true);
    }

    private void scoreButtonActionPerformed(ActionEvent evt) {
        logAction("Viewed Score");
        this.dispose();
        new ShowScore(username).setVisible(true);
    }

    private void backButtonActionPerformed(ActionEvent evt) {
        this.dispose();
        new quizapp.ui.Login().setVisible(true); // Make sure LoginPage exists
    }

    private void logAction(String action) {
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Database not connected! Action not logged.");
            return;
        }
        try {
            String query = "INSERT INTO activity_log (user_id, action, details) VALUES ((SELECT id FROM users WHERE username = ?), ?, ?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, action);
            pst.setString(3, "Student action in dashboard");
            pst.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to log action: " + e.getMessage());
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new StudentDashboard("student_username").setVisible(true));
    }
}
