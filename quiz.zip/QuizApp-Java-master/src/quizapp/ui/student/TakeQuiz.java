package quizapp.ui.student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import repositories.QuestionRepository;
import repositories.StudentRepository;
import services.StudentService;

public class TakeQuiz extends JFrame {
    private final String username;
    private final String subject;
    private final String level;
    private final String set;

    private int myScore;
    private int currentQuestionNumber;
    private String currentAnswer;
    private final int totalQuestions = 15;
    private final QuestionRepository questionService;
    private final StudentService studentService;
    private List<Map<String, String>> questions;
    private Timer timer;
    private int timeLeft;

    private JLabel questionLabel, timerLabel;
    private JRadioButton optionARadio, optionBRadio, optionCRadio, optionDRadio;
    private ButtonGroup answerGroup;
    private JButton nextButton, submitButton;
    private JPanel mainPanel;
    private ImageIcon backgroundIcon;

    public TakeQuiz(String username, String subject, String level, String set) {
        this.username = username;
        this.subject = subject;
        this.level = level;
        this.set = set;
        this.myScore = 0;
        this.currentQuestionNumber = 1;

        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundIcon != null) {
                    Image img = backgroundIcon.getImage();
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        mainPanel.setLayout(null);

        questionService = new QuestionRepository();
        studentService = new StudentRepository();

        questions = questionService.getQuestions(subject, level, set, totalQuestions);

        if (questions == null || questions.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No questions available for " + subject + " - " + level + " (Set " + set + ")!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        backgroundIcon = new ImageIcon(getClass().getResource("/quizapp/ui/student/studentDashboard-page.jpg"));

        initComponents();
        loadQuestion();

        setContentPane(mainPanel);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void initComponents() {
        timerLabel = new JLabel("Time: 15", SwingConstants.CENTER);
        timerLabel.setBounds(550, 20, 100, 30);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 16));
        timerLabel.setForeground(Color.RED);
        mainPanel.add(timerLabel);

        questionLabel = new JLabel("", SwingConstants.CENTER);
        questionLabel.setBounds(50, 50, 600, 50);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 18));
        questionLabel.setForeground(Color.WHITE);
        mainPanel.add(questionLabel);

        optionARadio = new JRadioButton();
        optionBRadio = new JRadioButton();
        optionCRadio = new JRadioButton();
        optionDRadio = new JRadioButton();

        answerGroup = new ButtonGroup();
        answerGroup.add(optionARadio);
        answerGroup.add(optionBRadio);
        answerGroup.add(optionCRadio);
        answerGroup.add(optionDRadio);

        styleRadioButton(optionARadio, 100, 150);
        styleRadioButton(optionBRadio, 100, 200);
        styleRadioButton(optionCRadio, 100, 250);
        styleRadioButton(optionDRadio, 100, 300);

        mainPanel.add(optionARadio);
        mainPanel.add(optionBRadio);
        mainPanel.add(optionCRadio);
        mainPanel.add(optionDRadio);

        nextButton = new JButton("Next");
        nextButton.setBounds(150, 370, 100, 40);
        nextButton.addActionListener(e -> loadNextQuestion());
        mainPanel.add(nextButton);

        submitButton = new JButton("Submit");
        submitButton.setBounds(280, 370, 100, 40);
        submitButton.addActionListener(e -> submitQuiz());
        submitButton.setVisible(false);
        mainPanel.add(submitButton);
    }

    private void styleRadioButton(JRadioButton radio, int x, int y) {
        radio.setBounds(x, y, 500, 30);
        radio.setOpaque(false);
        radio.setForeground(Color.WHITE);
        radio.setFont(new Font("Arial", Font.PLAIN, 16));
    }

    private void loadQuestion() {
        if (currentQuestionNumber > questions.size()) return;

        resetTimer();
        Map<String, String> currentQuestion = questions.get(currentQuestionNumber - 1);
        questionLabel.setText(currentQuestion.get("question"));
        optionARadio.setText("A) " + currentQuestion.get("optionA"));
        optionBRadio.setText("B) " + currentQuestion.get("optionB"));
        optionCRadio.setText("C) " + currentQuestion.get("optionC"));
        optionDRadio.setText("D) " + currentQuestion.get("optionD"));
        currentAnswer = currentQuestion.get("answer");

        answerGroup.clearSelection();
    }

    private void loadNextQuestion() {
        String selectedAnswer = getSelectedAnswer();
        if (selectedAnswer != null && selectedAnswer.equals(currentAnswer)) {
            myScore++;
        }

        currentQuestionNumber++;

        if (currentQuestionNumber > totalQuestions) {
            nextButton.setVisible(false);
            submitButton.setVisible(true);
            if (timer != null) timer.cancel();
        } else {
            loadQuestion();
        }
    }

    private String getSelectedAnswer() {
        if (optionARadio.isSelected()) return "A";
        if (optionBRadio.isSelected()) return "B";
        if (optionCRadio.isSelected()) return "C";
        if (optionDRadio.isSelected()) return "D";
        return null;
    }

    private void submitQuiz() {
        storeResultInDatabase();
        JOptionPane.showMessageDialog(this, "Quiz completed!\nYour score: " + myScore + "/" + totalQuestions);

        // Redirect to StudentDashboard
        new StudentDashboard(username).setVisible(true);
        dispose();
    }

    private void storeResultInDatabase() {
        String url = "jdbc:postgresql://localhost:5432/data";
        String user = "postgres";
        String password = "root";

        String insertQuery = "INSERT INTO quiz_results (username, subject, level, set, marks, total_marks) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

            pstmt.setString(1, username);
            pstmt.setString(2, subject);
            pstmt.setString(3, level);
            pstmt.setString(4, set);
            pstmt.setInt(5, myScore);
            pstmt.setInt(6, totalQuestions);

            pstmt.executeUpdate();
            System.out.println("Quiz result stored successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to store quiz result!", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void resetTimer() {
        if (timer != null) {
            timer.cancel();
        }

        timeLeft = 15;
        timerLabel.setText("Time: " + timeLeft);

        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (timeLeft > 0) {
                    timeLeft--;
                    timerLabel.setText("Time: " + timeLeft);
                } else {
                    timer.cancel();
                    SwingUtilities.invokeLater(() -> loadNextQuestion());
                }
            }
        }, 1000, 1000);
    }
}
