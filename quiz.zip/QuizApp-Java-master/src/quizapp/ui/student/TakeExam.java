package quizapp.ui.student;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import repositories.QuestionRepository;
import repositories.StudentRepository;
import services.QuestionService;
import services.StudentService;

public class TakeExam extends javax.swing.JFrame {

    private final String username;
    private int myScore;
    private int currentQuestionNumber;
    private String currentAnswer;
    private int totalQuestions;
    private final QuestionService questionService;
    private final StudentService studentService;
    private List<Map<String, String>> questions;
    private Timer timer;
    private int timeLeft;
    
    public TakeExam(String username) {
        initComponents();
        this.username = username;
        myScore = 0;
        currentQuestionNumber = 1;
        totalQuestions = 5;
        finishLabel.setVisible(false);
        finish.setVisible(false);
        scoreLabel.setVisible(false);
        score.setVisible(false);
        questionService = new QuestionRepository();
        questions = questionService.getRandomQuestions(totalQuestions);
        studentService = new StudentRepository();
        loadQuestion();
    }

    private void loadQuestion() {
        resetTimer();
        Map<String, String> currentQuestionMap = questions.get(currentQuestionNumber - 1);
        question.setText(currentQuestionMap.get("question"));
        optionA.setText(currentQuestionMap.get("optionA"));
        optionB.setText(currentQuestionMap.get("optionB"));
        optionC.setText(currentQuestionMap.get("optionC"));
        optionD.setText(currentQuestionMap.get("optionD"));
        currentAnswer = currentQuestionMap.get("answer");
        
        answerGroup.clearSelection();
        
        if (currentQuestionNumber < totalQuestions) {
            next.setVisible(true);
            submit.setVisible(false);
        } else {
            next.setVisible(false);
            submit.setVisible(true);
        }
    }

    private void resetTimer() {
        if (timer != null) {
            timer.cancel();
        }
        timeLeft = 15;
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if (timeLeft > 0) {
                    timeLeft--;
                } else {
                    timer.cancel();
                    loadNextQuestion();
                }
            }
        }, 1000, 1000);
    }

    private void loadNextQuestion() {
        if (getSelectedAnswer().equals(currentAnswer)) {
            myScore++;
        }
        if (currentQuestionNumber < totalQuestions) {
            currentQuestionNumber++;
            loadQuestion();
        } else {
            displayScore();
        }
    }

    private String getSelectedAnswer() {
        if (optionARadio.isSelected()) return "A";
        if (optionBRadio.isSelected()) return "B";
        if (optionCRadio.isSelected()) return "C";
        if (optionDRadio.isSelected()) return "D";
        return "";
    }

    private void displayScore() {
        finishLabel.setVisible(true);
        finish.setVisible(true);
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        finishLabel = new javax.swing.JLabel();
        question = new javax.swing.JLabel();
        optionA = new javax.swing.JLabel();
        optionB = new javax.swing.JLabel();
        optionC = new javax.swing.JLabel();
        optionD = new javax.swing.JLabel();
        optionARadio = new javax.swing.JRadioButton();
        optionBRadio = new javax.swing.JRadioButton();
        optionCRadio = new javax.swing.JRadioButton();
        optionDRadio = new javax.swing.JRadioButton();
        answerGroup = new javax.swing.ButtonGroup();
        finish = new javax.swing.JButton();
        scoreLabel = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        next = new javax.swing.JButton();
        score = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        answerGroup.add(optionARadio);
        answerGroup.add(optionBRadio);
        answerGroup.add(optionCRadio);
        answerGroup.add(optionDRadio);
        
        finish.setText("Finish");
        finish.addActionListener(evt -> {
            scoreLabel.setVisible(true);
            score.setVisible(true);
            score.setText("" + myScore);
            studentService.updateStudentMarks(username, "" + myScore);
        });

        next.setText("Next");
        next.addActionListener(evt -> loadNextQuestion());

        submit.setText("Submit");
        submit.addActionListener(evt -> {
            if (getSelectedAnswer().equals(currentAnswer)) {
                myScore++;
            }
            displayScore();
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1)
        );

        pack();
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new TakeExam("").setVisible(true));
    }

    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel finishLabel;
    private javax.swing.JLabel question;
    private javax.swing.JLabel optionA;
    private javax.swing.JLabel optionB;
    private javax.swing.JLabel optionC;
    private javax.swing.JLabel optionD;
    private javax.swing.JRadioButton optionARadio;
    private javax.swing.JRadioButton optionBRadio;
    private javax.swing.JRadioButton optionCRadio;
    private javax.swing.JRadioButton optionDRadio;
    private javax.swing.ButtonGroup answerGroup;
    private javax.swing.JButton finish;
    private javax.swing.JLabel scoreLabel;
    private javax.swing.JButton submit;
    private javax.swing.JButton next;
    private javax.swing.JLabel score;
}