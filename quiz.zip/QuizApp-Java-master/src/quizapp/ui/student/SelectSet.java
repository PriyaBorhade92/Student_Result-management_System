package quizapp.ui.student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import database.DatabaseConnection;

public class SelectSet extends JFrame {
    private final String username;
    private final String subject;
    private final String level;

    private ImageIcon backgroundIcon;
    private JPanel jPanel1;
    private JLabel jLabel1;
    private JButton setAButton;
    private JButton setBButton;
    private JButton setCButton;
    private JButton backButton;

    public SelectSet(String username, String subject, String level) {
        this.username = username;
        this.subject = subject;
        this.level = level;
        initComponents();
    }

    private void initComponents() {
        // Load background image
        backgroundIcon = new ImageIcon(getClass().getResource("/quizapp/ui/student/studentDashboard-page.jpg"));

        jPanel1 = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundIcon != null) {
                    Image img = backgroundIcon.getImage();
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Scale image to panel size
                }
            }
        };
        jPanel1.setLayout(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen with controls
        setResizable(true);
        setUndecorated(false);

        // Back Button styled
        backButton = new JButton("←");
        backButton.setFont(new Font("SansSerif", Font.BOLD, 40));
        backButton.setBackground(new Color(0,0,0,0));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createEmptyBorder());
        backButton.setForeground(Color.WHITE);
        backButton.setBounds(20, 20, 60, 40);
        backButton.addActionListener(evt -> {
            this.dispose();
            new SelectLevel(username, subject).setVisible(true);
        });
        jPanel1.add(backButton);

        // Title Label
        jLabel1 = new JLabel("Select Set");
        jLabel1.setFont(new Font("SansSerif", Font.BOLD, 36));
        jLabel1.setForeground(Color.WHITE);
        jPanel1.add(jLabel1);

        // Set Buttons
        setAButton = createSetButton("Set A", evt -> setButtonActionPerformed(evt, "A"));
        setBButton = createSetButton("Set B", evt -> setButtonActionPerformed(evt, "B"));
        setCButton = createSetButton("Set C", evt -> setButtonActionPerformed(evt, "C"));

        jPanel1.add(setAButton);
        jPanel1.add(setBButton);
        jPanel1.add(setCButton);

        getContentPane().add(jPanel1);

        // Dynamic repositioning
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                positionComponents();
            }
        });

        setVisible(true);
    }

    private JButton createSetButton(String text, java.awt.event.ActionListener action) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 20));
        button.setBackground(new Color(0, 102, 204));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.addActionListener(action);
        return button;
    }

    private void positionComponents() {
        int panelWidth = jPanel1.getWidth();
        int panelHeight = jPanel1.getHeight();

        int centerX = panelWidth / 2;
        int topY = panelHeight / 4;

        jLabel1.setBounds(centerX - 100, topY - 60, 300, 40);
        setAButton.setBounds(centerX - 75, topY + 50, 150, 50);
        setBButton.setBounds(centerX - 75, topY + 150, 150, 50);
        setCButton.setBounds(centerX - 75, topY + 250, 150, 50);
    }

    private void setButtonActionPerformed(ActionEvent evt, String set) {
        if (saveSetSelection(username, subject, level, set)) {
            JOptionPane.showMessageDialog(this, "Set selected successfully. Proceeding to quiz.", "Success", JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
            new TakeQuiz(username, subject, level, set).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to save set selection.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean saveSetSelection(String username, String subject, String level, String set) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            int studentId = getStudentId(username, conn);
            int subjectId = getSubjectId(subject, conn);
            int levelId = getLevelId(level, conn);

            if (studentId == -1 || subjectId == -1 || levelId == -1) {
                JOptionPane.showMessageDialog(this, "Error: Invalid student, subject, or level.");
                return false;
            }

            String sql = "INSERT INTO exam_sets (student_id, subject_id, level_id, set_name) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, studentId);
                stmt.setInt(2, subjectId);
                stmt.setInt(3, levelId);
                stmt.setString(4, set);
                stmt.executeUpdate();
            }

            logUserAction(studentId, "Selected set: " + set, conn);
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private void logUserAction(int studentId, String action, Connection conn) throws SQLException {
        String logSql = "INSERT INTO activity_log (user_id, action) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(logSql)) {
            stmt.setInt(1, studentId);
            stmt.setString(2, action);
            stmt.executeUpdate();
        }
    }

    private int getStudentId(String username, Connection conn) throws SQLException {
        String sql = "SELECT id FROM users WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return -1;
    }

    private int getSubjectId(String subject, Connection conn) throws SQLException {
        String sql = "SELECT id FROM subjects WHERE name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, subject);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return -1;
    }

    private int getLevelId(String level, Connection conn) throws SQLException {
        String sql = "SELECT id FROM levels WHERE name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, level);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SelectSet("testuser", "Math", "Easy").setVisible(true));
    }
}
