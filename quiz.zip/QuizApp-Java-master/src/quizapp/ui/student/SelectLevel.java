package quizapp.ui.student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import database.DatabaseConnection;

public class SelectLevel extends javax.swing.JFrame {
    private final String username;
    private final String subject;
    private ImageIcon backgroundIcon;

    private JPanel jPanel1;
    private JLabel jLabel1;
    private JButton easyButton;
    private JButton mediumButton;
    private JButton hardButton;
    private JLabel jLabel6;
    private JButton backButton;  // Added back button

    public SelectLevel(String username, String subject) {
        this.username = username;
        this.subject = subject;
        initComponents();
    }

    private void initComponents() {
        // Load background image
        backgroundIcon = new ImageIcon(getClass().getResource("/quizapp/ui/student/studentDashboard-page.jpg"));

        jPanel1 = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundIcon != null) {
                    Image img = backgroundIcon.getImage();
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Scale image to panel size
                }
            }
        };
        jPanel1.setLayout(null);

        // Set JFrame properties
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen with window controls
        setResizable(true); // Allow resizing
        setUndecorated(false); // Show window controls (close, minimize, maximize)

        // Back Button (Optional, for navigation)
        backButton = new JButton("←");
        backButton.setFont(new Font("SansSerif", Font.BOLD, 40));
        backButton.setBackground(new Color(0,0,0,0));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createEmptyBorder()); // Remove border
        backButton.setForeground(Color.WHITE);
        backButton.setBounds(20, 20, 60, 40);
        backButton.addActionListener(e -> {
            this.dispose();
            new StudentDashboard(username).setVisible(true);
        });
        jPanel1.add(backButton);

        // Select Level Label
        jLabel1 = new JLabel("Select Level");
        jLabel1.setFont(new Font("SansSerif", Font.BOLD, 36));
        jLabel1.setForeground(Color.WHITE);
        jPanel1.add(jLabel1);

        // Level Buttons
        easyButton = createLevelButton("Easy", evt -> levelButtonActionPerformed(evt, "Easy"));
        mediumButton = createLevelButton("Medium", evt -> levelButtonActionPerformed(evt, "Medium"));
        hardButton = createLevelButton("Hard", evt -> levelButtonActionPerformed(evt, "Hard"));

        // Add buttons to panel
        jPanel1.add(easyButton);
        jPanel1.add(mediumButton);
        jPanel1.add(hardButton);

        // Add background image to panel
        jLabel6 = new JLabel(new ImageIcon(getClass().getResource("/quizapp/ui/student/studentDashboard-page.jpg")));
        jPanel1.add(jLabel6);

        // Add panel to frame
        getContentPane().add(jPanel1);

        // Handle component resize for repositioning
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                positionComponents();
            }
        });

        setVisible(true);
    }

    private JButton createLevelButton(String text, java.awt.event.ActionListener action) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 20));
        button.setBackground(new Color(0, 102, 204));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.addActionListener(action);
        return button;
    }

    private void positionComponents() {
        int panelWidth = jPanel1.getWidth();
        int panelHeight = jPanel1.getHeight();

        int centerX = panelWidth / 2;
        int topY = panelHeight / 4;

        jLabel1.setBounds(centerX - 100, topY - 60, 300, 40);
        easyButton.setBounds(centerX - 75, topY +50, 150, 50);
        mediumButton.setBounds(centerX - 75, topY +150, 150, 50);
        hardButton.setBounds(centerX - 75, topY + 250, 150, 50);
    }

    private void levelButtonActionPerformed(ActionEvent evt, String level) {
        if (saveLevelSelection(username, subject, level)) {
            this.dispose();
            new SelectSet(username, subject, level).setVisible(true); // ✅ Transition fixed!
        } else {
            JOptionPane.showMessageDialog(this, "Failed to save level selection.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Saves the selected level in the database.
     */
    private boolean saveLevelSelection(String username, String subject, String level) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            int studentId = getStudentId(username, conn);
            int subjectId = getSubjectId(subject, conn);
            int levelId = getLevelId(level, conn);

            if (studentId == -1 || subjectId == -1 || levelId == -1) {
                JOptionPane.showMessageDialog(this, "Error: Invalid student, subject, or level.");
                return false;
            }

            // Insert user selection into the exams table
            String sql = "INSERT INTO exams (student_id, subject_id, level_id, score) VALUES (?, ?, ?, 0)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, studentId);
                stmt.setInt(2, subjectId);
                stmt.setInt(3, levelId);
                stmt.executeUpdate();
                System.out.println("Level selection saved successfully.");
            }

            // Log action in activity_log
            logUserAction(studentId, "Selected level: " + level, conn);

            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private void logUserAction(int studentId, String action, Connection conn) throws SQLException {
        String logSql = "INSERT INTO activity_log (user_id, action) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(logSql)) {
            stmt.setInt(1, studentId);
            stmt.setString(2, action);
            stmt.executeUpdate();
        }
    }

    private int getStudentId(String username, Connection conn) throws SQLException {
        String sql = "SELECT id FROM users WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return -1;
    }

    private int getSubjectId(String subject, Connection conn) throws SQLException {
        String sql = "SELECT id FROM subjects WHERE name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, subject);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return -1;
    }

    private int getLevelId(String level, Connection conn) throws SQLException {
        String sql = "SELECT id FROM levels WHERE name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, level);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return -1;
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new SelectLevel("testuser", "Math").setVisible(true));
    }
}
