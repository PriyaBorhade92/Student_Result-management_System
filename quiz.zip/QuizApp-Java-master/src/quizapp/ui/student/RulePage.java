/*package quizapp.ui.student;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class RulePage extends javax.swing.JFrame {
    private final String username;
    private final String subject;

    public RulePage(String username, String subject) {
        this.username = username;
        this.subject = subject;
        initComponents();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        startTestButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(480, 360));
        setMinimumSize(new java.awt.Dimension(480, 360));
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 24));
        jLabel1.setText("Start Test");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 200, 30));

        startTestButton.setText("Start Test");
        startTestButton.addActionListener(this::startTestButtonActionPerformed);
        jPanel1.add(startTestButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 120, 50));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/quizapp/ui/student/studentDashboard-page.jpg")));
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 650));

        getContentPane().add(jPanel1);
        pack();
    }

    private void startTestButtonActionPerformed(ActionEvent evt) {
        this.dispose();
        new TakeQuiz(username, subject).setVisible(true);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new SelectLevel("", "").setVisible(true));
    }

    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JButton startTestButton;
}*/

