package quizapp.ui.student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import database.DatabaseConnection;

public class SelectSubject extends javax.swing.JFrame {
    private final String username;
    private ImageIcon backgroundIcon;

    private JPanel jPanel1;
    private JLabel jLabel1;
    private JButton cButton;
    private JButton javaButton;
    private JButton pythonButton;
    private JButton phpButton;
    private JButton htmlButton;
    private JButton backButton;

    public SelectSubject(String username) {
        this.username = username;
        initComponents();
    }

    private void initComponents() {
        // Load background image
        backgroundIcon = new ImageIcon(getClass().getResource("/quizapp/ui/student/studentDashboard-page.jpg"));

        jPanel1 = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundIcon != null) {
                    Image img = backgroundIcon.getImage();
                    g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Scale image to panel size
                }
            }
        };
        jPanel1.setLayout(null);

        // Set JFrame properties
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen
        setResizable(true); // Allow resizing (will show window controls)

        // Back Button (Optional, for navigation)
        backButton = new JButton("←");
        backButton.setFont(new Font("SansSerif", Font.BOLD, 20));
        backButton.setBackground(new Color(255, 255, 255, 180));
        backButton.setFocusPainted(false);
        backButton.setBounds(20, 20, 60, 40);
        backButton.addActionListener(e -> {
            this.dispose();
            new StudentDashboard(username).setVisible(true);
        });
        jPanel1.add(backButton);

        // Subject Selection Label
        jLabel1 = new JLabel("Select Subject");
        jLabel1.setFont(new java.awt.Font("SansSerif", Font.BOLD, 36));
        jLabel1.setForeground(Color.WHITE);
        jPanel1.add(jLabel1);

        // Subject Buttons
        cButton = createSubjectButton("C", evt -> subjectButtonActionPerformed(evt, "C", 1));
        javaButton = createSubjectButton("Java", evt -> subjectButtonActionPerformed(evt, "Java", 2));
        pythonButton = createSubjectButton("Python", evt -> subjectButtonActionPerformed(evt, "Python", 3));
        phpButton = createSubjectButton("PHP", evt -> subjectButtonActionPerformed(evt, "PHP", 5));
        htmlButton = createSubjectButton("HTML", evt -> subjectButtonActionPerformed(evt, "HTML", 4));

        // Add buttons to panel
        jPanel1.add(cButton);
        jPanel1.add(javaButton);
        jPanel1.add(pythonButton);
        jPanel1.add(phpButton);
        jPanel1.add(htmlButton);

        // Add panel to frame
        getContentPane().add(jPanel1);

        // Handle component resize for repositioning
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                positionComponents();
            }
        });

        setVisible(true);
    }

    private JButton createSubjectButton(String text, java.awt.event.ActionListener action) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 20));
        button.setBackground(new Color(0, 102, 204));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.addActionListener(action);
        return button;
    }

    private void positionComponents() {
        int panelWidth = jPanel1.getWidth();
        int panelHeight = jPanel1.getHeight();

        int centerX = panelWidth / 2;
        int topY = panelHeight / 4;

        jLabel1.setBounds(centerX - 150, topY - 60, 300, 40);
        cButton.setBounds(centerX - 220, topY +50, 150, 50);
        javaButton.setBounds(centerX + 70, topY +50, 150, 50);
        pythonButton.setBounds(centerX - 220, topY + 150, 150, 50);
        phpButton.setBounds(centerX + 70, topY + 150, 150, 50);
        htmlButton.setBounds(centerX - 75, topY + 250, 150, 50);

        backButton.setBounds(20, 20, 60, 40);
    }

    private void subjectButtonActionPerformed(ActionEvent evt, String subject, int subjectId) {
        if (saveSubjectSelection(username, subjectId)) {
            this.dispose();
            new SelectLevel(username, subject).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to save subject selection.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean saveSubjectSelection(String username, int subjectId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            int userId = getUserId(username, conn);
            if (userId == -1) {
                JOptionPane.showMessageDialog(this, "Error: User not found.");
                return false;
            }

            String sql = "INSERT INTO student_subjects (student_id, subject_id) VALUES (?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, userId);
                stmt.setInt(2, subjectId);
                stmt.executeUpdate();
                System.out.println("Subject selection saved successfully.");
            }
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private int getUserId(String username, Connection conn) throws SQLException {
        String sql = "SELECT id FROM users WHERE username = ? AND role = 'student'";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return -1;
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new SelectSubject("testuser").setVisible(true));
    }
}
