package quizapp.ui;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import quizapp.ui.student.StudentDashboard;
import quizapp.ui.admin.AdminDashboard; // Import Admin Dashboard

public class Login extends javax.swing.JFrame {
    private Connection conn;

    public Login() {
        initComponents();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        connectToDatabase();
    }

    private void connectToDatabase() {
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/data", "postgres", "root");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database Connection Failed: " + e.getMessage());
        }
    }

    private void initComponents() {
        jPanel1 = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon(getClass().getResource("/quizapp/ui/login-page.jpg"));
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        };
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1 = new JLabel("Password");
        jLabel2 = new JLabel("Username");
        jLabel3 = new JLabel("Login As");
        jLabel4 = new JLabel("Login");
        username = new JTextField();
        password = new JPasswordField();
        loginType = new JComboBox<>(new String[]{"Student", "Admin"});
        loginButton = new JButton("Exit");
        loginButton1 = new JButton("Login");

        jLabel1.setFont(new Font("sansserif", Font.BOLD, 14));
        jLabel1.setForeground(new Color(255, 255, 0));

        jLabel2.setFont(new Font("sansserif", Font.BOLD, 14));
        jLabel2.setForeground(new Color(255, 255, 0));
        
        jLabel3.setFont(new Font("sansserif", Font.BOLD, 14));
        jLabel3.setForeground(new Color(255, 255, 0));
        
        jLabel4.setFont(new Font("sansserif", Font.BOLD, 24));
        jLabel4.setForeground(new Color(0, 255, 255));

        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 210, 90, 40));
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, 90, 40));
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 280, 90, 40));
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 40, 140, 60));
        jPanel1.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 140, 210, 40));
        jPanel1.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 210, 210, 40));
        jPanel1.add(loginType, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 280, 210, 40));

        loginButton.setBackground(new Color(153, 0, 0));
        loginButton.addActionListener(evt -> System.exit(0));
        jPanel1.add(loginButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 350, 120, 40));

        loginButton1.setBackground(new Color(0, 153, 0));
        loginButton1.addActionListener(evt -> handleLogin());
        jPanel1.add(loginButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 350, 120, 40));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().add(jPanel1);
        pack();
    }

    private void handleLogin() {
        String user = username.getText().trim();
        String pass = new String(password.getPassword()).trim();
        String role = (String) loginType.getSelectedItem();

        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username and Password cannot be empty!");
            return;
        }

        try {
            String query = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, user);
            pst.setString(2, pass);
            pst.setString(3, role.toLowerCase());
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                this.dispose();
                if (role.equals("Student")) {
                    new StudentDashboard(user).setVisible(true);
                } else {
                    new AdminDashboard().setVisible(true);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }

    private JPanel jPanel1;
    private JLabel jLabel1, jLabel2, jLabel3, jLabel4;
    private JTextField username;
    private JPasswordField password;
    private JComboBox<String> loginType;
    private JButton loginButton, loginButton1;
}
