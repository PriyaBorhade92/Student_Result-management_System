package repositories;

import models.Question;
import services.QuestionService;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestionRepository implements QuestionService {

    private final Connection conn;

    public QuestionRepository() {
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/data", "postgres", "root");
        } catch (SQLException e) {
            throw new RuntimeException("Database connection failed!", e);
        }
    }

    @Override
    public boolean addQuestion(Question question) {
        String sql = "INSERT INTO questions (subject_id, level_id, set_id, question_text, option_a, option_b, option_c, option_d, correct_option) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, question.getSubjectId());
            pst.setInt(2, question.getLevelId());
            pst.setInt(3, question.getSetId());
            pst.setString(4, question.getQuestionText());
            pst.setString(5, question.getOptionA());
            pst.setString(6, question.getOptionB());
            pst.setString(7, question.getOptionC());
            pst.setString(8, question.getOptionD());
            pst.setString(9, question.getCorrectOption());
            
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Map<String, String>> getQuestions(String subject, String level, String set, int numberOfQuestions) {
        List<Map<String, String>> questions = new ArrayList<>();
        String sql = "SELECT q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_option " +
                     "FROM questions q " +
                     "JOIN subjects s ON q.subject_id = s.id " +
                     "JOIN levels l ON q.level_id = l.id " +
                     "JOIN sets se ON q.set_id = se.id " +
                     "WHERE s.name = ? AND l.name = ? AND se.name = ? " +
                     "ORDER BY RANDOM() LIMIT ?";

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, subject);
            pst.setString(2, level);
            pst.setString(3, set);
            pst.setInt(4, numberOfQuestions);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Map<String, String> questionMap = new HashMap<>();
                questionMap.put("question", rs.getString("question_text"));
                questionMap.put("optionA", rs.getString("option_a"));
                questionMap.put("optionB", rs.getString("option_b"));
                questionMap.put("optionC", rs.getString("option_c"));
                questionMap.put("optionD", rs.getString("option_d"));
                questionMap.put("answer", rs.getString("correct_option"));

                questions.add(questionMap);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return questions;
    }

	@Override
	public List<Map<String, String>> getRandomQuestions(int numberOfQuestions) {
		// TODO Auto-generated method stub
		return null;
	}
}
