package repositories;

import java.sql.*;
import java.util.*;

import services.StudentService;

public class StudentRepository implements StudentService {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/data";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "root";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    @Override
    public boolean getLogin(String username, String password) {
        String query = "SELECT password FROM users WHERE username = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("password");
                return storedPassword.equals(password); // Ideally, use password hashing
            }
            return false;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean addStudent(String username, String password) {
        String query = "INSERT INTO users (username, password, role) VALUES (?, ?, 'student')";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Map<String, String>> getAllStudent() {
        String query = "SELECT id, username FROM users WHERE role = 'student'";
        List<Map<String, String>> students = new ArrayList<>();
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Map<String, String> student = new HashMap<>();
                student.put("id", String.valueOf(rs.getInt("id")));
                student.put("username", rs.getString("username"));
                students.add(student);
            }
            return students;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return Collections.emptyList(); // Return empty list instead of null
        }
    }

    @Override
    public boolean updateStudentMarks(String username, String marks) {
        String query = "UPDATE exams SET score = ? WHERE student_id = (SELECT id FROM users WHERE username = ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            int score;
            try {
                score = Integer.parseInt(marks); // Convert marks to int safely
            } catch (NumberFormatException e) {
                System.err.println("Invalid marks value: " + marks);
                return false; // Handle invalid marks input
            }

            stmt.setInt(1, score);
            stmt.setString(2, username);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
