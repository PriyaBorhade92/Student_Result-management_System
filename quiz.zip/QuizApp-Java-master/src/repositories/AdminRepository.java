package repositories;

import java.sql.*;
import java.util.List;
import java.util.Map;

import services.AdminService;

public class AdminRepository implements AdminService {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/data"; // Update DB name
    private static final String DB_USER = "postgres"; // Update your DB username
    private static final String DB_PASSWORD = "root"; // Update your DB password

    public AdminRepository() {
        try {
            Class.forName("org.postgresql.Driver"); // Load PostgreSQL driver
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("PostgreSQL JDBC Driver not found.");
        }
    }

    // ✅ Create Student Account (Prevents Duplicate Usernames)
    @Override
    public boolean createStudent(String username, String password) {
        String checkQuery = "SELECT COUNT(*) FROM users WHERE username = ?";
        String insertQuery = "INSERT INTO users (username, password, role) VALUES (?, ?, 'student')";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
             PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {

            // Check if username already exists
            checkStmt.setString(1, username);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                System.out.println("❌ Username already exists: " + username);
                return false; // Username exists
            }

            // Insert new student
            insertStmt.setString(1, username);
            insertStmt.setString(2, password);
            int rowsInserted = insertStmt.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            System.out.println("❌ Error inserting student: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // ✅ Admin Login
    @Override
    public boolean getLogin(String username, String password) {
        String query = "SELECT * FROM users WHERE username = ? AND password = ? AND role = 'admin'";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next(); // Returns true if a record is found
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

	@Override
	public List<Map<String, String>> getStudentMarks() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, String>> getStudentsWithResults() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, String>> getStudentQuizResults(int studentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, String>> getQuizResults() {
		// TODO Auto-generated method stub
		return null;
	}
}
