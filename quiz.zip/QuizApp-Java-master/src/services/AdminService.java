package services;

import java.util.List;
import java.util.Map;

public interface AdminService {

    boolean getLogin(String username, String password);

    boolean createStudent(String username, String password);

    List<Map<String, String>> getStudentMarks();

    List<Map<String, String>> getStudentsWithResults();

    List<Map<String, String>> getStudentQuizResults(int studentId);

    List<Map<String, String>> getQuizResults();  // ✅ Now properly implemented in AdminRepository
}
