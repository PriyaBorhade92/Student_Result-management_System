package services;

import java.util.List;
import java.util.Map;

public interface StudentService {
    boolean getLogin(String username, String password);
    boolean addStudent(String username, String password);
    List<Map<String, String>> getAllStudent();
    boolean updateStudentMarks(String username, String marks);
}
