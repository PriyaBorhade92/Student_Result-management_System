package models;

public class Question {

    public final String question;
    public final String optionA;
    public final String optionB;
    public final String optionC;
    public final String optionD;
    public final String answer;

    public Question(String question, String optionA, String optionB, String optionC, String optionD, String answer) {
        this.question = question;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.answer = answer;
    }

	public int getSubjectId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getLevelId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getSetId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getQuestionText() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getOptionA() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getOptionB() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getOptionC() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getOptionD() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getCorrectOption() {
		// TODO Auto-generated method stub
		return null;
	}
}
