from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Teacher
    path('', views.student_list, name="student_list"),
    path('create/', views.student_create, name="student_create"),
    path('update/<int:pk>/', views.student_update, name="student_update"),
    path('delete/<int:pk>/', views.student_delete, name="student_delete"),

    # Student
    path('result/', views.student_result, name="student_result"),

    # Auth
    path('login/', auth_views.LoginView.as_view(template_name="login.html"), name="login"),
    path('logout/', auth_views.LogoutView.as_view(), name="logout"),
]
