from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Student
from django import forms

# Form
class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ["roll_number", "name", "course", "subject", "marks"]

# Teacher - READ
@login_required
def student_list(request):
    students = Student.objects.all()
    return render(request, "student_list.html", {"students": students})

# Teacher - CREATE
@login_required
def student_create(request):
    form = StudentForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect("student_list")
    return render(request, "student_form.html", {"form": form})

# Teacher - UPDATE
@login_required
def student_update(request, pk):
    student = get_object_or_404(Student, pk=pk)
    form = StudentForm(request.POST or None, instance=student)
    if form.is_valid():
        form.save()
        return redirect("student_list")
    return render(request, "student_form.html", {"form": form})

# Teacher - DELETE
@login_required
def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == "POST":
        student.delete()
        return redirect("student_list")
    return render(request, "student_confirm_delete.html", {"student": student})

# Student - RESULT (no login needed)
def student_result(request):
    students = None
    if request.method == "POST":
        roll = request.POST.get("roll_number")
        students = Student.objects.filter(roll_number=roll)
    return render(request, "student_result.html", {"students": students})
